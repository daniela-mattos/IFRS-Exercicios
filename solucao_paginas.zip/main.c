/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

void calcLiteraria(){
printf(" ┌|||||||||||||||||||||||||||||||||| •✧✧• ||||||||||||||||||||||||||||||||||┐\n");
printf("|									     |\n");
printf("|		 C A L C U L A D O R A  L I T E R Á R I A                    |\n");
printf("|									     |\n");
printf(" └|||||||||||||||||||||||||||||||||| •✧✧• ||||||||||||||||||||||||||||||||||┘\n");

}

int main()
{
    int paginasDia=10, tempoGastoInt=119, paginas=0;
    double restoDivTempo=0;
    
    paginas=paginasDia;
    
    if((tempoGastoInt % 60)>0) {
          restoDivTempo = (tempoGastoInt % 60);
          paginasDia = ((restoDivTempo/100) * paginas) + paginas;
    }
    printf("%d", paginasDia);


        


    return 0;
}

